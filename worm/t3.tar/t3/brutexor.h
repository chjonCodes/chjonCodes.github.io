#ifndef BRUTEXOR_H_
#define BRUTEXOR_H_

#define MAX_CHAR 4

typedef struct login *login;
struct login {
	char user[4];
	char passwd[4];
};

int get_user(char *, int, int, login, char *, int);
int get_passwd(char *, char *, int, int, login, char *, int);
int brutexor(void);

#endif
