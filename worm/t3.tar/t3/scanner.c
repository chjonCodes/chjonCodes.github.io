#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <linux/tcp.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include "scanner.h"
#include "lista.h"

int scan(int argc, char **argv) {
	char *first_IP, *IP;
	int IP_min, IP_max, port_min, port_max;
	int i, j;
	char *IP_opt = argv[1];
	char *port_opt;
	time_t now;
	struct tm *timeinfo;
	char buffer[BUFFER_SIZE];
	int status;

	signal(SIGPIPE, SIG_IGN);
	if (argc == 3) port_opt = argv[2];
	else port_opt = "1-65535";
	get_option(IP_opt, port_opt, &first_IP, &IP_min, &IP_max, &port_min, &port_max);
	IP = (char *) malloc(sizeof(char)*MAX_IP_SIZE);
	time(&now);
	timeinfo = localtime(&now);
	strftime (buffer, 80 ,"%a %d %b %Y %T %Z", timeinfo);
	printf("Varredura iniciada em %s\n", buffer);
	if(IP_min != IP_max)
		printf("IP: %s%d-%d\n", first_IP, IP_min, IP_max);
	else
		printf("IP: %s%d\n", first_IP, IP_min);
	if (port_min != port_max)
		printf("Portas: %d-%d\n", port_min, port_max);
	else
		printf("Porta: %d\n", port_min);
	printf("---\n");
	for (i = IP_min; i <= IP_max; i++) {
		for (j = port_min; j <= port_max; j++) {
			sprintf(IP, "%s%d", first_IP, i);
			/* status = scanner(IP, j); */
			if (status == -2) j = port_max;
			memset(IP, '\0', sizeof(MAX_IP_SIZE));
		}
	}
	return 0;
}

void get_option(char *IPs, char *ports, char **first_IP, int *IP_min, int *IP_max, int *port_min, int *port_max) {
	int i, j, size;
	char a, min[5], max[5];
	char *mask;

	i = 0; j = 0;
	do {
		a = IPs[i];
		if (a == '.') {
			memset(&min, '\0', sizeof(min));
			j = 0;
		}
		min[j++] = IPs[++i];
	} while (i < MAX_IP_SIZE && (IPs[i] != '\0' && IPs[i] != '-'));
	size = i;
	mask = (char *)malloc(sizeof(char)*i);
	size -= j-1;
	for (j = 0; j < size; j++)
		mask[j] = IPs[j];
	*first_IP = mask;
	j = 0;
	if (IPs[i] != '\0') {
		i++;
		do {
			max[j] = IPs[i];
			j++; i++;
		} while(j < 3 && IPs[i] != '\0');
		*IP_max = atoi(max);
	} else
		*IP_max = atoi(min);
	*IP_min = atoi(min);

	memset(&min, '\0', sizeof(min));
	memset(&max, '\0', sizeof(max));
	i = 0;
	do {
		min[i] = ports[i];
		i++;
	} while(i < MAX_PORT_SIZE && ports[i] != '\0' && ports[i] != '-');
	if(ports[i] != '\0') {
		j = 0; i++;
		do {
			max[j] = ports[i];
			i++; j++;
		} while(j < MAX_PORT_SIZE && ports[i] != '\0');
		*port_max = atoi(max);
	} else
		*port_max = atoi(min);
	*port_min = atoi(min);
}

int scanner(char *IP, int port, lista conexoes) {
	int sd;
	char buffer[BUFFER_SIZE];
	struct sockaddr_in target_addr;
	struct timeval tmsg, tcon;
	int opts, status;
	char msg[] = "attack";
	conexao c;
	fd_set readfds, writefds, connectfds;

	tcon.tv_sec = 2;
	tcon.tv_usec = 0;
	tmsg.tv_sec = 2;
	tmsg.tv_usec = 0;

	if ((sd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
		#if DEBUG
		fprintf(stderr, "Não foi possível abrir o socket!\n");
		#endif
		close(sd);
		return -1;
	}

	target_addr.sin_family = AF_INET;
	target_addr.sin_port = htons(port);
	target_addr.sin_addr.s_addr = inet_addr(IP);

	opts = fcntl(sd, F_GETFL);
	fcntl(sd, F_SETFL, opts | O_NONBLOCK);

	FD_ZERO(&connectfds);
	FD_SET(sd, &connectfds);

	if (connect(sd, (struct sockaddr *) &target_addr, sizeof(target_addr)) < 0) {
		if (errno == EINPROGRESS) {
			fcntl(sd, F_SETFL, opts);
			if( (select (sd + 1, &connectfds, &connectfds, NULL, &tcon) > 0) ) {
				FD_CLR(sd, &connectfds);
				socklen_t len = sizeof(int);
				status = 0;
				if (getsockopt(sd, SOL_SOCKET, SO_ERROR, &status, &len ) < 0) {
					#if DEBUG
					printf("Erro na conexão\n");
					#endif
					close(sd);
					return -1;
				}
				if (status == EINPROGRESS) {
					#if DEBUG
					printf("Não conectado1\n");
					#endif
					close(sd);
					errno = status;
					return -1;
				} else {
					#if DEBUG
					printf("Connected\n");
					#endif
				}
			} else {
				/*printf("%s\tConnection timed out\n", IP);*/
				close(sd);
				return -2;
			}
		} else {
			#if DEBUG
			printf("%s\t%d\tFalha ao conectar\n", IP, port);
			#endif
			close(sd);
			return -1;
		}
	}

	fcntl(sd, F_SETFL, opts);

	FD_ZERO(&writefds);
	FD_SET(sd, &writefds);

	if ( (select(sd+1, NULL, &writefds, NULL, &tmsg)) <= 0) {
		#if DEBUG
		printf("Erro no envio: select\n");
		#endif
		close(sd);
		return -1;
	}

	memset(buffer, '\0', BUFFER_SIZE);

	memcpy(buffer, msg, sizeof(msg));

	if (FD_ISSET(sd, &writefds)) {
		FD_CLR(sd, &writefds);
		if (write(sd, buffer, sizeof(buffer)) < 0) {
			close(sd);
			return -1;
		}
	}

	printf("%s\t%d", IP, port);

	c = malloc(sizeof(struct conexao));
	sprintf(c->IP, "%s", IP);
	c->port = port;
	insere_lista(c, conexoes);

	FD_ZERO(&readfds);
	FD_SET(sd, &readfds);

	if ( (select(sd+1, &readfds, NULL, NULL, &tmsg)) <= 0) {
		#if DEBUG
		printf("Erro no read: select\n");
		#endif
		printf("\n");
		close(sd);
		return -1;
	}
	memset(buffer, '\0', BUFFER_SIZE);

	if (FD_ISSET(sd, &readfds)) {
		FD_CLR(sd, &readfds);
		if (read(sd, buffer, sizeof(buffer)) <= 0) {
			printf("\n");
			close(sd);
			return -1;
		}
		printf("\t%s", buffer);
		sprintf(c->banner, "%s", buffer);
	} else {
		printf("\n");
	}
	close(sd);
	return 1;
}
