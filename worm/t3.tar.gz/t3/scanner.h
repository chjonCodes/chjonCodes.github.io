#ifndef SCANNER_H_
#define SCANNER_H_

#include "lista.h"

#define MAX_IP_SIZE 15
#define MAX_PORT_SIZE 5
#define BUFFER_SIZE 512

#define DEBUG 0

typedef struct conexao *conexao;
struct conexao {
	char IP[MAX_IP_SIZE], banner[BUFFER_SIZE];
	int port;
};

int scan(int, char **);
void get_option(char *, char *, char **, int *, int *, int *, int *);
int scanner(char *, int, lista);

#endif
